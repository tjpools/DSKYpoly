# DSKYpoly
A low-level symbolic engine built in C and x86-64 assembly exploring algebraic structure - where Galois meets the machine.
